({
    onStudentClick : function(component, event, helper) {
        alert(component.get('v.student').Name);
    }
})