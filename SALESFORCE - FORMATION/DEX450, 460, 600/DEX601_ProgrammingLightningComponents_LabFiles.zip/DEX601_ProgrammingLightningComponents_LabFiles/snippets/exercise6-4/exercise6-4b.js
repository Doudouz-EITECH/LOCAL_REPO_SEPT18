onContactEdit: function(component,event,helper) {
    var title = "Edit Contact - ";
    var contactId = event.getParam('pk');
    var rec = event.getParam('rec');
    if (rec) {
        title += rec.Name;
    }
	// exercise 6-4, insert code here

}