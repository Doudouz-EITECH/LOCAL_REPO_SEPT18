({
	loadRecord : function(component) {
		component.find('recordHandler').reloadRecord();
	}
})