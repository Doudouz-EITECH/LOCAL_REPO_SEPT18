({
    onStudentSelected: function(component, event, helper) {

        var contactId = event.getParam('contactId');

        component.set('v.contactId',contactId);
        component.find('recordLoader').reloadRecord();

        helper.callServer(
            component,
            "c.getNotesByStudent",
            function(response) {
                var aResults = [];
                for (var i=0; i<response.length; i++) {
                    var obj = {
                        courseAttendeeId: response[i].Id,
                        startDate: response[i].Course_Delivery__r.Start_Date__c,
                        courseName: response[i].Course_Delivery__r.Course__r.Name
                    }
                    if (response[i].InstructorNotes__c) {
                        obj.instructorNotes = response[i].InstructorNotes__c;
                    } else {
                        obj.instructorNotes = "No notes";
                    }
                    aResults.push(obj);
                }
                component.set('v.history',aResults);
            }, {
                contactId : contactId
            }
        );
    },
    onFullDetails: function(component, event, helper) {
        var evt = $A.get("event.force:navigateToSObject");
        if (evt) {
            evt.setParams({
                "recordId": component.get('v.contactId'),
                "slideDevName": "detail"
            });
            evt.fire();
        } else {
            alert('Feature not supported on this platform');
        }
    }
})