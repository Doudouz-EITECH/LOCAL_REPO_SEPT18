({
    onCourseAttendeeChange : function(component, event, helper) {
        helper.loadRecord(component);
    },
    onHistoryChange : function(component, event, helper) {
        var history = component.get('v.history');
        if (history.length> 0) {
            component.set('v.courseAttendeeId', history[0].courseAttendeeId);
            helper.loadRecord(component);
        }
    },
    onSave: function(component, event, helper) {
      var service = component.find('recordHandler');
        service.saveRecord($A.getCallback(function (saveResult) {
            if (saveResult.state === 'SUCCESS' || saveResult.state === 'DRAFT') {
                alert("Record Saved");
            }
        }));
    },
    handleRecordUpdated: function(component, event, helper) {

    }
})