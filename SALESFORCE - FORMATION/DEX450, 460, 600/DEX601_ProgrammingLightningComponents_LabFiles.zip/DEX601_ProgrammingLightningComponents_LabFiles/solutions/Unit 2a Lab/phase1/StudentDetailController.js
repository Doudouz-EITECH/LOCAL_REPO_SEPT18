({
    onStudentSelected : function(component, event, helper) {
        var contactId = event.getParam('contactId');
        component.set('v.contactId',contactId);
        component.find('recordLoader').reloadRecord();
    },
    onFullDetails: function(component, event, helper) {
        var evt = $A.get("event.force:navigateToSObject");
        if (evt) {
            evt.setParams({
                "recordId": component.get('v.contactId'),
                "slideDevName": "detail"
            });
            evt.fire();
        } else {
            alert('Feature not supported on this platform');
        }
    }
})