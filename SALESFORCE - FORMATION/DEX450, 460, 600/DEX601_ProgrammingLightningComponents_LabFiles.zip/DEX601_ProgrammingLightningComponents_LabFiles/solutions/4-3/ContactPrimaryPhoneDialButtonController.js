({
    doInit: function(component, event, helper) {
        component.find('recordHandler').reloadRecord();
    }
})