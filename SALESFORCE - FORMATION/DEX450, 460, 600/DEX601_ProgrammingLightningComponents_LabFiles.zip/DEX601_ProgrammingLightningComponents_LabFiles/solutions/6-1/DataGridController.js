({
    doInit : function(component, event, helper) {
        helper.onInit(component);
    }
})