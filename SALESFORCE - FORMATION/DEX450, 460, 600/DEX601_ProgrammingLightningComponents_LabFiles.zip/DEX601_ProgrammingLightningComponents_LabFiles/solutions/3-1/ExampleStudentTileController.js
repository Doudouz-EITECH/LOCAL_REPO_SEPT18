({
    onStudentSelected : function(component, event, helper) {
        alert("You selected contact " + event.getParam('contactId'));
    }
})